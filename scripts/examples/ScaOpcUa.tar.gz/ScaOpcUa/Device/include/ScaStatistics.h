/*
 * ScaStatistics.h
 *
 *  Created on: 19 Mar 2019
 *      Author: pnikiel
 */

#ifndef DEVICE_INCLUDE_SCASTATISTICS_H_
#define DEVICE_INCLUDE_SCASTATISTICS_H_


struct ScaStatistics
{
    double requestRate;
    ScaStatistics() : requestRate(0) {}
};


#endif /* DEVICE_INCLUDE_SCASTATISTICS_H_ */
