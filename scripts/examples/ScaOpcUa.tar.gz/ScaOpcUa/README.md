# OpcUaSca

[![build status](https://gitlab.cern.ch/atlas-dcs-opcua-servers/ScaOpcUa/badges/master/build.svg)](https://gitlab.cern.ch/atlas-dcs-opcua-servers/ScaOpcUa/commits/master)
