#define VERSION_STR "Unofficial developer version. This software wasn't build using official release build script."
